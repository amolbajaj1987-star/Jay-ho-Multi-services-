package com.multiservices.app

import android.os.Bundle
import android.graphics.Color
import android.view.Gravity
import android.widget.*
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {
 private val services=listOf(
  "🏠 घर साफसफाई","🔧 प्लंबिंग सेवा","⚡ इलेक्ट्रिकल सेवा","🎨 रंगकाम / पेंटिंग",
  "❄️ एसी व उपकरण दुरुस्ती","🚗 कार / बाईक सर्व्हिस","💻 संगणक / मोबाईल दुरुस्ती",
  "🚚 पॅकर्स व मूव्हर्स","🌳 बागकाम सेवा","🧹 कीटक नियंत्रण","👷 कामगार / तंत्रज्ञ"
 )
 override fun onCreate(b:Bundle?){super.onCreate(b);home()}
 private fun home(){
  val s=ScrollView(this); val l=LinearLayout(this); l.orientation=LinearLayout.VERTICAL;l.setPadding(24,24,24,30)
  val logo=ImageView(this).apply {
   setImageResource(R.drawable.jay_ho_logo)
   adjustViewBounds=true
   scaleType=ImageView.ScaleType.CENTER_INSIDE
}
  l.addView(logo, LinearLayout.LayoutParams(-1, 300))
  val h=TextView(this);h.text="जय हो मल्टी सर्व्हिसेस";h.textSize=30f;h.gravity=Gravity.CENTER;h.setTextColor(Color.rgb(13,71,161))
  val sub=TextView(this);sub.text="आपल्या सर्व सेवा — एकाच ठिकाणी";sub.textSize=17f;sub.gravity=Gravity.CENTER;sub.setPadding(0,8,0,24)
  l.addView(h);l.addView(sub)
  services.forEach{ x-> val b=Button(this);b.text=x;b.textSize=16f;b.isAllCaps=false;b.setOnClickListener{book(x)};l.addView(b,LinearLayout.LayoutParams(-1,64).apply{setMargins(0,0,0,10)})}
  s.addView(l);setContentView(s)
 }
 private fun book(service:String){
  val s=ScrollView(this);val l=LinearLayout(this);l.orientation=LinearLayout.VERTICAL;l.setPadding(28,28,28,30)
  fun edit(h:String,lines:Int=1)=EditText(this).apply{hint=h;minLines=lines}
  val h=TextView(this);h.text="सेवा बुक करा\n$service";h.textSize=24f;h.setTextColor(Color.rgb(13,71,161));h.setPadding(0,0,0,20)
  val n=edit("आपले नाव");val p=edit("मोबाईल नंबर");p.inputType=2;val a=edit("सेवेचा पत्ता",3);val d=edit("तारीख आणि वेळ")
  val b=Button(this);b.text="बुकिंग निश्चित करा";b.isAllCaps=false
  listOf(h,n,p,a,d,b).forEach{l.addView(it)}
  b.setOnClickListener{Toast.makeText(this,"आपली सेवा बुकिंग विनंती यशस्वीरीत्या पाठवली आहे.",Toast.LENGTH_LONG).show();home()}
  s.addView(l);setContentView(s)
 }
}
